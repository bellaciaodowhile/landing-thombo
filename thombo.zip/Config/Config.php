<?php 
    // const BASE_URL = 'http://localhost/thombo/';
    const BASE_URL = 'https://5fbc-181-208-25-142.ngrok-free.app/thombo/';
    
    // Datos de la conexión de la base de datos
    const DB_HOST = "localhost";
    const DB_NAME = "thombo";
    const DB_USER = "root";
    const DB_PASSWORD = "";
    const DB_CHARSET = "charset=utf8";
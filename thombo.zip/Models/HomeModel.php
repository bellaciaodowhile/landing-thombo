<?php 
    class HomeModel extends MySql{
        public function __construct() {
            parent::__construct();
        }
    }
<?php require_once 'Views/Templates/Scripts.php'; ?>
</body>
</html>